"""
This an Home Assignment #1: it contains exercise about using 
variables in python 3
"""

title = "Kickstart My Heart"
artist = "Motley Crue"
year = 1989
genre = "Glam Metal"
duration_in_seconds = 288
rating = 4.9
vocals = "Vince Neil"
guitars = "Mick Mars"
bass = "Nikki Sixx"
drums = "Tommy Lee"
label = "Electra"
songwriter = "Nikki Sixx"
producer ='Bob Rock'
album = "Dr Feelgood"

print(title)
print(artist)
print(year)
print(genre)
print(duration_in_seconds)
print(rating)
print(vocals)
print(guitars)
print(bass)
print(drums)
print(label)
print(songwriter)
print(producer)
print(album)